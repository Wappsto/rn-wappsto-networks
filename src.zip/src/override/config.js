export {use as useConfig} from '../configureWappstoRedux';
