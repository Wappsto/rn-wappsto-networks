export {replaceComponent} from '../navigation';
