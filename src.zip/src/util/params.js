export const userGetRequest = 'userGetRequest';
export const userFetched = 'userFetched';
export const selectedDeviceName = 'selectedDevice';
export const iotNetworkListAdd = 'iotNetworkListAdd';
export const iotModelListAdd = 'iotModelListAdd';
export const currentPage = 'currentPage';
export const manufacturerAsOwnerErrorCode = 105000008;
